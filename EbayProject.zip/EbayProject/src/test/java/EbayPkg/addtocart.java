package EbayPkg;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class addtocart extends TestBase {

	public static void searbook()
	{
		try {
			WebElement se = driver.findElement(By.xpath("//input[contains(@title,'Search')]"));
			se.sendKeys("Book");

			WebElement searchbutto =	driver.findElement(By.xpath("//button[contains(@id,'gh-search-btn')]"));
			searchbutto.click();

			Thread.sleep(Duration.ofSeconds(10));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void selectbook()
	{
		List<WebElement> li = driver.findElements(By.xpath("//div[contains(@class, 's-item__title')]"));

		WebElement firstbook = 	li.get(2);

		JavascriptExecutor js = (JavascriptExecutor)driver ;

		js.executeScript("arguments[0].click();", firstbook);

	}

	public static void wh()
	{
		try {
			String parenttab =	driver.getWindowHandle();
			System.out.println(parenttab);

			Set<String> lis = driver.getWindowHandles();

			ArrayList<String> ss = new ArrayList<String>(lis);

			System.out.println(ss);
			Thread.sleep(Duration.ofSeconds(5));
			driver.switchTo().window(ss.get(1));
			Thread.sleep(Duration.ofSeconds(5));
			WebElement atcart = driver.findElement(By.xpath("//a[contains(@id, 'atcBtn_btn_1')]"));
			atcart.click();

		}
		catch (Exception e) {
			System.out.println(e);
		}	
	}

	public static void checkcart()
	{
		try {

			Thread.sleep(Duration.ofSeconds(5));
			WebElement dd = driver.findElement(By.xpath("//span[contains(@class,'gh-cart__icon')]//span"));

			String i = dd.getText();

			int n = Integer.parseInt(i);

			System.out.println(n);

			if(n>0)
			{
				System.out.println("Test is passed");
			}
		}
		catch (Exception e) {
			System.out.println(e);
		}

	}

	public static void main(String[] args) {

		TestBase.browserSetup();
		TestBase.max();
		TestBase.puturl("https://www.ebay.com/");
		addtocart.searbook();
		addtocart.selectbook();
		addtocart.wh();
		addtocart.checkcart();
		TestBase.teardown();
	}

}
