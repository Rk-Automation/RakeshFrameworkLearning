package EbayPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestBase {

	// Global Variable
	public static WebDriver driver ;

	public static void browserSetup()
	{
		driver = new ChromeDriver();
	}

	public static void max()
	{
		driver.manage().window().maximize();
	}

	// Method Overloading
	public static void puturl(String url)
	{
		driver.get(url);
	}

	public static void teardown()
	{
		driver.quit();
	}


}
