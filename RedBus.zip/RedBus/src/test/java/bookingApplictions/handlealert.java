package bookingApplictions;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import Configurations.ReusableData;
import SeleniumFunctions.readBrowserDriver;
import SeleniumFunctions.seleniumUIActions;

public class handlealert {
	@BeforeMethod
	public void precodition() throws IOException
	{
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.url);
		readBrowserDriver.maximizeBroser();
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.amazonurl);
		readBrowserDriver.maximizeBroser();
		readBrowserDriver.driver.findElement(By.xpath("//input[@type='email']")).sendKeys("5656898952");
		readBrowserDriver.driver.findElement(By.xpath("//*[@id=\"continue\"]")).click(); 
		Alert amz = readBrowserDriver.driver.switchTo().alert();
		amz.accept();
		//readBrowserDriver.driver.findElement(By.xpath("//*[@id=\"auth-error-message-box\"]/div/div")).getText();						 
     	String txtmsg = readBrowserDriver.driver.switchTo().alert().getText();
		System.out.println(txtmsg);		
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.wait_url);
		readBrowserDriver.maximizeBroser();
				
	}
	@Test(priority = 1)
	public void handleAlert() throws IOException
	{
		
		readBrowserDriver.readbrowser(ReusableData.chromedriverpath,ReusableData.browsertype,ReusableData.alerturl);
	    readBrowserDriver.maximizeBroser();
	    seleniumUIActions.handleAlert();
	    
	}
	
	@AfterMethod
	public void closebrowser() throws IOException
	{
		
	    readBrowserDriver.driver.close();
	}
}
