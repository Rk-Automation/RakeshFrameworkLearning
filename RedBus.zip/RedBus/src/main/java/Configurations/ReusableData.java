package Configurations;
//Author:Rakesh
public interface ReusableData {
	
	public static String browsertype="webdriver.chrome.driver";
	public static String chromedriverpath="D:\\Automation_Testing_Course\\RedBus\\RedBus\\Browser\\chromedriver.exe";
	public static String url="https://demo.guru99.com/test/newtours/register.php";
	public static String alerturl="https://demo.guru99.com/test/delete_customer.php";
	public static String amazonurl = "https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Fref_%3Dnav_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0";
		public static String Env="QA";
	public static String PROD_url="https://www.redbus.com/";
	public static String OR_File_Location="D:\\Automation_Testing_Course\\RedBus\\RedBus\\ObjectProperties\\OR.properties";
	public static String Excel_File_Location="D:\\Automation_Testing_Course\\RedBus\\RedBus\\src\\test\\resources\\testData";
	public static String wait_url = "https://www.hyrtutorials.com/p/waits-demo.html";

}
