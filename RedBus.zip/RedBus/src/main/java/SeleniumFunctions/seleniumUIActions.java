package SeleniumFunctions;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Configurations.ReusableData;
import excel.readDataFromExcel;

public class seleniumUIActions {
	
	public static void enterVlues() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.ContactInformation.FirstName.input"))).sendKeys(readDataFromExcel.fetchexcelData(1, 1));
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.ContactInformation.lastName.input"))).sendKeys(readDataFromExcel.fetchexcelData(1, 2));
	
	}

	public static void clickHomes() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.HomePage.a"))).click();
		
	
	}
	
	public static void selectdropdown() throws IOException
	{
		
		WebElement ele = readBrowserDriver.driver.findElement(By.xpath(readdatafromfile.readdatafromOR("Register.MailingInfo.Country.select")));
		Select sel = new Select(ele);
		sel.selectByValue("ALGERIA");
		
	
	}
	
	public static void handleAlert() throws IOException
	{
		readBrowserDriver.driver.findElement(By.xpath("//input[@name='submit']")).click();
		Alert obj = readBrowserDriver.driver.switchTo().alert();
		String msg1 = obj.getText();
		System.out.println(msg1);
		obj.accept();
		String msg = obj.getText();
		System.out.println(msg);
		//obj.dismiss();
		
	} 
	public static void handlewait()
	
	{
				//hard code wait or implicit wait
				//explicit wait
				//fluent wait
				
		//Implicit Wait
//				readBrowserDriver.driver.findElement(By.xpath("//button[@id='btn1']")).click();
//				try {
//					readBrowserDriver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
//					
//				} catch (NoSuchElementException e) {
//					readBrowserDriver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
//				}
//				
//				readBrowserDriver.driver.findElement(By.xpath("(//input[@id='txt1'])[1]")).click();
//				
		//Explicit Wait:	
				readBrowserDriver.driver.findElement(By.xpath("//button[@id='btn1']")).click();
				WebDriverWait wait = new WebDriverWait(readBrowserDriver.driver, Duration.ofSeconds(20));
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@id='txt1'])[1]"))).sendKeys("Rakesh");
				
				readBrowserDriver.driver.findElement(By.xpath("//button[@id='btn2']")).click();
				WebDriverWait wait1 = new WebDriverWait(readBrowserDriver.driver, Duration.ofSeconds(20));
				wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@id='txt2'])[1]"))).sendKeys("KRISH");
								
	}	
	
	
	public static void AmazonAlert() throws IOException
	{
//		readBrowserDriver.driver.findElement(By.xpath("//input[@name='submit']")).click();
//		readBrowserDriver.driver.findElement(By.xpath("//input[@type='email']")).sendKeys("5656898952");
//		readBrowserDriver.driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
//		Alert amz = readBrowserDriver.driver.switchTo().alert();
//		String txtmsg = amz.getText();
//		System.out.println(+txtmsg);
//		amz.accept();
//		String msg = amz.getText();
//		System.out.println(msg);
//		//obj.dismiss();txtmsg
		
	}
	public static void MenuList() throws IOException
	{
		Actions actions = new Actions(readBrowserDriver.driver); 
		WebElement tutorialMenu = readBrowserDriver.driver.findElement(By.xpath("//a[text()='Tutorials']"));
		actions.moveToElement(tutorialMenu).perform();
		WebElement subMenu1 = readBrowserDriver.driver.findElement(By.xpath("//li/a[text()='Testing']"));
		actions.moveToElement(subMenu1).perform();
		WebElement subMenu2 = readBrowserDriver.driver.findElement(By.xpath("//li/a[text()='Selenium']"));
		actions.moveToElement(subMenu2).click();
		
		
	}
}
