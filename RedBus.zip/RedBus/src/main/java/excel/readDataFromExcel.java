package excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Configurations.ReusableData;

public class readDataFromExcel {

	public static String fetchexcelData(int rownum , int column) throws IOException {
		
		FileInputStream fs = new FileInputStream(ReusableData.Excel_File_Location);
		XSSFWorkbook workbook = new XSSFWorkbook(fs);
		XSSFSheet sheet = workbook.getSheetAt(0);
//		Row row = sheet.getRow(rownum);
//		Cell cell = row.getCell(column);
		String data =sheet.getRow(rownum).getCell(column).toString();
		return data;
		
		
	}
}
