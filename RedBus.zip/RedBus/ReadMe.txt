Please download\ copy Maven Dependencies for pom.xml from below: 
https://mvnrepository.com/artifact/org.seleniumhq.selenium/selenium-java/4.25.0

Please download Chromedriver from below location based on your OS version (32 bit\64 bit) 
https://googlechromelabs.github.io/chrome-for-testing/#stable -- 
"https://storage.googleapis.com/chrome-for-testing-public/129.0.6668.100/win64/chromedriver-win64.zip" -- Copy & paste in browser to download chromedriver

