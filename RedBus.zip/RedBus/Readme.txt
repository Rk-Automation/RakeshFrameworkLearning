Please download selenium from here:https://mvnrepository.com/artifact/org.seleniumhq.selenium/selenium-java/4.25.0
download driver from here= https://googlechromelabs.github.io/chrome-for-testing/#stable
githubURL=https://github.com/atharavyadav/batch45
testngurl=https://mvnrepository.com/artifact/org.testng/testng/7.10.2

